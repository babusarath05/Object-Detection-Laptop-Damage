# -*- coding: utf-8 -*-
"""
Created on Tue Jan  3 00:21:36 2023

@author: sarathbabu.karunanit
"""

from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import os
import cv2 as cv
import numpy as np

app = Flask(__name__)

upload_folder = os.path.join('static', 'uploads')

app.config['UPLOAD'] = upload_folder

output_folder = os.path.join('static', 'output')

app.config['OUTPUT'] = output_folder

logo_folder = os.path.join('static', 'logo')

app.config['LOGO'] = logo_folder

logo_img = os.path.join(app.config['LOGO'],'lv_logo.png')

bg_img =  os.path.join(app.config['LOGO'],'bg.jpg')



def yolo_out(img):
    
    yolo = cv.dnn.readNetFromDarknet('yolov3_testing.cfg', 'yolov3_training_2000.weights')
    
    classes=[]

    with open("classes.txt","r") as f:
        classes=f.read().splitlines()
    
    blob = cv.dnn.blobFromImage(img, 1/255.0, (416, 416), swapRB=True, crop=False)
    height, width, channels = img.shape
    
    yolo.setInput(blob)
    
    output_layers_name=yolo.getUnconnectedOutLayersNames()
    
    layeroutput=yolo.forward(output_layers_name)
    
    boxes=[]
    confidences=[]
    class_ids=[]
    
    for output in layeroutput:
        for detection in output:
            score=detection[5:]
            class_id=np.argmax(score)
            confidence=score[class_id]
            
            if confidence>0.7:
                center_x=int(detection[0]*width)
                center_y=int(detection[1]*height)
                w=int(detection[2]*width)
                h=int(detection[3]*height)
                
                x=int(center_x-w/2)
                y=int(center_y-h/2)
                
                boxes.append([x, y, w, h])
                confidences.append(float(confidence))
                class_ids.append(class_id)
                
    indexes = cv.dnn.NMSBoxes(boxes, confidences, 0.5, 0.4)
    font = cv.FONT_HERSHEY_PLAIN
    #colors = np.random.uniform(0, 255, size=(len(classes), 3))
    colors=[(0,255,255),(255,255,0)]
    
    if len(indexes)>0:
        for i in indexes.flatten():
            x, y, w, h = boxes[i]
            label = str(classes[class_ids[i]])
            color = colors[class_ids[i]]
            cv.rectangle(img, (x, y), (x + w, y + h), color, 2)
            cv.putText(img, label, (x, y - 10), font, 2, color, 2)
    
    #img=cv.cvtColor(img,cv.COLOR_BGR2RGB)
    return img

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    logo_img = os.path.join(app.config['LOGO'],'lv_logo.png')
    bg_img =  os.path.join(app.config['LOGO'],'bg.jpg')
    
    if request.method == 'POST':
        file = request.files['img']
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD'], filename))
        img = os.path.join(app.config['UPLOAD'], filename)
        
        loc=os.getcwd()
        input_img_loc=loc+'\\static\\uploads\\'+filename
        output_img_loc=loc+'\\static\\output\\'+filename
        
        input_img = cv.imread(input_img_loc)
        output_img = yolo_out(input_img)
        cv.imwrite(output_img_loc,output_img)
        out_img = os.path.join(app.config['OUTPUT'], filename)
        
       # img_grey=cv.imread(img,0)
       # file.save(os.path.join(app.config['UPLOAD'], filename))
       # img = os.path.join(app.config['UPLOAD'], filename)
        
        
        return render_template('image_render.html', img1=img,img2=out_img,img3=logo_img,img4=bg_img)
    return render_template('image_render.html',img3=logo_img,img4=bg_img)


if __name__ == '__main__':
    app.run(debug=True)
